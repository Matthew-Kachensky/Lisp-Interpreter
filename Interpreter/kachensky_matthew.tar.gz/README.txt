This project was done on python 3.9.7 - 3.10.4
and on a windows OS

Functions will not work if not surrounded by ()
example: (defun add (x y) (+ x y))
(add (8 3))     -will work
(add 8 3)       -will not work

T or NIL does not have to be surrounded by ()
example: 
(if (and (< 10 20) T) (3) (4))     -will work

To run this code, do: "py .\Clisp.py" while in the directory
This will execute the program